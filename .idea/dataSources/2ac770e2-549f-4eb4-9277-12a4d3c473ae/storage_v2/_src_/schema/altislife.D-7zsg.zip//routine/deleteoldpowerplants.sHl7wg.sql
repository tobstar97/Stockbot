create procedure deleteOldPowerplants(IN deleteOldPowerplants int)
  BEGIN
	DELETE FROM `powerplants` WHERE `zustand` < 1;
END;

